public class Rennen extends Rennstruktur
{
    public int max_snails = 100;
    public String name;
    public int snail_number;
    public Rennschnecke[] snails;
    public float race_distance;
    
    public Rennen(String new_name, float new_race_distance){
        name = new_name;
        race_distance = new_race_distance;
        snails = new Rennschnecke[max_snails];
        snail_number = 0;
    }
    
    public void addRennschnecke(Rennschnecke neue_rennschnecke){
        snails[snail_number] = neue_rennschnecke;
        snail_number++;
    }
    
    // Kann übersprungen werden, falls zu schwer
    public void removeRennschnecke(String name){
        int index = -1;
        for(int i = 0; i < snail_number; i++){
            if(snails[i].name.equals(name)){
                index = i;
            }
        }
        
        if(index != -1){
            Rennschnecke[] new_snails = new Rennschnecke[max_snails];
            for(int i = 0; i < snail_number; i++){
                if(i < index){
                    new_snails[i] = snails[i];
                } else if(i > index){
                    new_snails[i - 1] = snails[i];
                }
            }
            
            snails = new_snails;
            snail_number--;
        }
    }
    
    public String getData(){
        String text = "";
        for(int i = 0; i < snail_number; i++){
            text = text + snails[i].getData() + "\n";
        }
        return text;
    }
    
    public Rennschnecke ermittleGewinner(){
        for(int i = 0; i < snail_number; i++){
            if(snails[i].distance >= race_distance){
                return snails[i];
            }
        }
        
        return null;
    }
    
    public void lasseSchneckenKriechen(){
        for(int i = 0; i < snail_number; i++){
            snails[i].krieche();
        }
    }
    
    public boolean durchfuehren(){
        lasseSchneckenKriechen();
        System.out.println(getData());
        Rennschnecke snail = ermittleGewinner();
        if(snail != null){
            System.out.println("=========================");
            System.out.println("Gewinner: " + snail.name);
            return true;
        }
        
        return false;
    }
}
