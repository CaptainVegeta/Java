public class Schneckenrennen
{    
    public static void main(String[] args){
        RennHandler handler = new RennHandler();
        Rennen rennen = new Rennen("cooles Rennen", 20);
        rennen.addRennschnecke(new Rennschnecke("Hans", "Arion lusitanicus", 2));
        rennen.addRennschnecke(new Rennschnecke("Müller", "Helix pomatia", 1.7f));
        rennen.addRennschnecke(new Rennschnecke("Kurt", "Arion lusitanicus", 2.1f));
        rennen.addRennschnecke(new Rennschnecke("Felix", "Limax maximus", 1.9f));
        handler.setRennen(rennen);
        handler.start();
    }
}
