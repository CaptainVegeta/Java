public class Rennschnecke
{
    public String name;
    public String race;
    public float max_velocity;
    public float distance;
    
    public Rennschnecke(String new_name, String new_race, float new_max_velocity){
        name = new_name;
        race = new_race;
        max_velocity = new_max_velocity;
        distance = 0;
    }
    
    public void krieche(){
        distance = distance + getRandom(0, max_velocity);
    }
    
    public float getRandom(float min, float max){
        return min + (float)(Math.random() * ((max - min) + 1));
    }
    
    public String getData(){
        return "Name: " + name + "\tDistanz: " + distance + "\tRasse: " + race + "\tmax. Geschwindigkeit: " + max_velocity;
    }
}
