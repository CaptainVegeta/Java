public class Rennstruktur
{
    public boolean durchfuehren(){
        return false;
    }
}
